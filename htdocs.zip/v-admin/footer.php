<?php require_once("../v-db/db.php");
$domain_head="http://".$_SERVER["SERVER_NAME"];
if($_SERVER["REQUEST_URI"]=="/v-admin/footer.php"){header("Location: $domain_head");}
$Forum_footer_conn=$conn->query("SELECT * FROM forum_footer WHERE verification=0");
$Forum_footer_conn->execute([]);
$Forum_footer = $Forum_footer_conn->fetch(PDO::FETCH_ASSOC);
$footer_number=$Forum_footer["Footer1"]+$Forum_footer["Footer2"]+$Forum_footer["Footer3"]+$Forum_footer["Footer4"];
if ($footer_number>0) {
$footer_number2 = 12/$footer_number;
?>
<section class="footer">
    <div class="container mt-1">
        <div class="row text-start">
            <?php if ($Forum_footer["Footer1"]==1) {
                echo'
            <div class="col-md-'.$footer_number2.'">
                <div class="footer1">
                    '.$Forum_footer["Footer1_content"].'
                </div>
            </div>
            ';
            }
            if ($Forum_footer["Footer2"]==1) {
                echo'
            <div class="col-md-'.$footer_number2.'">
                <div class="footer1">
                    '.$Forum_footer["Footer2_content"].'
                </div>
            </div>
            ';
            }
            if ($Forum_footer["Footer3"]==1) {
                echo'
            <div class="col-md-'.$footer_number2.'">
                <div class="footer1">
                    '.$Forum_footer["Footer3_content"].'
                </div>
            </div>
            ';
            }
            if ($Forum_footer["Footer4"]==1) {
                echo'
            <div class="col-md-'.$footer_number2.'">
                <div class="footer1">
                    '.$Forum_footer["Footer4_content"].'
                </div>
            </div>
            ';
            }
            
        ?>
        </div>
    </div>
</section>
<?php }?>
<section class="footer-copright">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <?php echo $Forum_footer["Footer_copyright"];?>
            </div>
        </div>
    </div>
</section>