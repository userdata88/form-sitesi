<?php 
require_once ("../v-db/db.php");
$domain_head="http://".$_SERVER["SERVER_NAME"];
if($_SERVER["REQUEST_URI"]=="/v-admin/head.php"){header("Location: $domain_head");}
echo '
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="title" content="'.$forum_settings["Forum_name"].'">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <meta name="description" content="'.$forum_settings["Forum_description"].'">
        <meta name="keywords" content="'.$forum_settings["Forum_tags"].'">
        <meta name="robots" content="index, nofollow">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <meta name="language" content="Turkish">
        <title>'.$forum_settings["Forum_name"].'</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
        <link href="../css/v-style.css" rel="stylesheet">
    </head>';
?>