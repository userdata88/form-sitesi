<?php
    require_once ("../v-db/db.php");
    if (@$_POST["id"]) {
    $userid= $_POST["id"];
    if (!empty($userid)) {
    $username_search_conn= $conn->prepare("SELECT * FROM users WHERE id LIKE ?");
    $username_search_conn->execute(["%$userid%"]);
    $username_search= $username_search_conn->fetch(PDO::FETCH_ASSOC);
    if (@$username_search) {
            if ($username_search["Rank"]==1) {
                ?> <script>$(function(){$("#rank-check").prop("checked",true);})</script> <?php
            }
    echo'     
    <div class="col-12 text-center" id="user-data">
        <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="user-id">User id: '.$username_search["id"].'</div>
        <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="username">Username: <a href="http://'.$_SERVER["SERVER_NAME"].'/profile.php/?id='.$username_search["id"].'" target="_blank">'.$username_search["Username"].'</a></div>
    </div>
        <div class="col-3 mt-4 sett-disabled2">Registration date:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Registration_date"].'</p></div>
        <div class="col-3 mt-4 sett-disabled2">Last entry:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Last_entry"].'</p></div>
        <div class="col-3 mt-4 sett-disabled2">Last ip:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Last_ip"].'</p></div>
        <div class="col-3 mt-4 sett-disabled2">Total topics:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Total_topics"].'</p></div>
        <div class="col-3 mt-4">Rank change:</div>
        <div class="col-7 mt-4"><input id="rank-check" name="rank" class="sett-disabled" type="checkbox"></div>
        <div class="col-3 mt-4">Username change:</div>
        <div class="col-7 mt-4"><input minlenght="5" class="sett-disabled" type="text"  name="username" style="width:100%;"value="'.$username_search["Username"].'"></div>
        <div class="col-3 mt-4">E-mail change:</div>
        <div class="col-7 mt-4"><input class="sett-disabled" type="email"  name="e-mail" style="width:100%;"value="'.$username_search["E_mail"].'"></div>
        <div class="col-3 mt-4">Photo change:</div>
        <div class="col-7 mt-4"><input class="sett-disabled2" type="url"  name="photo" style="width:100%;"value="'.$username_search["Photo"].'"></div>
        <div class="col-3 mt-4">About change:</div>
        <div class="col-7 mt-4"><textarea class="sett-disabled" name="about" style="width:100%;">'.$username_search["About"].'</textarea></div>
        <div class="col-3 mt-4">Signature change:</div>
        <div class="col-7 mt-4"><textarea class="sett-disabled" name="signature" style="width:100%;">'.$username_search["Signature"].'</textarea></div>
        <div id="settings-button" class="col-12 mt-4 text-center settings-button"><b><input id="disabled-button" name="submit" type="submit" value="Save"></b><b><input class="ml-5" id="disabled-button" name="submit" type="submit" value="Delete"></b></div>
';
}
    else {
        echo'    
        <div class="col-sm-6 mt-4" id="user-id">User id: Unkown</div>
        <div class="col-sm-6 mt-4" id="username">Username: Unkown</div>';
    }
}
}
elseif (@$_POST["Username"]) {
$username= $_POST["Username"];
if (!empty($username)) {
$username_search_conn= $conn->prepare("SELECT * FROM users WHERE Username LIKE ?");
$username_search_conn->execute(["%$username%"]);
$username_search= $username_search_conn->fetch(PDO::FETCH_ASSOC);
if (@$username_search) {
    if ($username_search["Rank"]==1) {
        ?> <script>$(function(){$("#rank-check").prop("checked",true);})</script> <?php
    }
echo'    
                                                <div class="col-12 text-center" id="user-data">
                                                    <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="user-id">User id: '.$username_search["id"].'</div>
                                                    <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="username">Username: <a href="http://'.$_SERVER["SERVER_NAME"].'/profile.php/?id='.$username_search["id"].'" target="_blank">'.$username_search["Username"].'</a></div>
                                                </div>
                                                    <div class="col-3 mt-4 sett-disabled2">Registration date:</div>
                                                    <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Registration_date"].'</p></div>
                                                    <div class="col-3 mt-4 sett-disabled2">Last entry:</div>
                                                    <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Last_entry"].'</p></div>
                                                    <div class="col-3 mt-4 sett-disabled2">Last ip:</div>
                                                    <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Last_ip"].'</p></div>
                                                    <div class="col-3 mt-4 sett-disabled2">Total topics:</div>
                                                    <div class="col-7 mt-4 sett-disabled2"><p>'.$username_search["Total_topics"].'</p></div>
                                                    <div class="col-3 mt-4">Rank change:</div>
                                                    <div class="col-7 mt-4"><input id="rank-check" name="rank" class="sett-disabled" type="checkbox"></div>
                                                    <div class="col-3 mt-4">Username change:</div>
                                                    <div class="col-7 mt-4"><input minlenght="5" class="sett-disabled" type="text"  name="username" style="width:100%;"value="'.$username_search["Username"].'"></div>
                                                    <div class="col-3 mt-4">E-mail change:</div>
                                                    <div class="col-7 mt-4"><input class="sett-disabled" type="email"  name="e-mail" style="width:100%;"value="'.$username_search["E_mail"].'"></div>
                                                    <div class="col-3 mt-4">Photo change:</div>
                                                    <div class="col-7 mt-4"><input class="sett-disabled2" type="url"  name="photo" style="width:100%;"value="'.$username_search["Photo"].'"></div>
                                                    <div class="col-3 mt-4">About change:</div>
                                                    <div class="col-7 mt-4"><textarea class="sett-disabled" name="about" style="width:100%;">'.$username_search["About"].'</textarea></div>
                                                    <div class="col-3 mt-4">Signature change:</div>
                                                    <div class="col-7 mt-4"><textarea class="sett-disabled" name="signature" style="width:100%;">'.$username_search["Signature"].'</textarea></div>
                                                    <div id="settings-button" class="col-12 mt-4 text-center settings-button"><b><input id="disabled-button" name="submit" type="submit" value="Save"></b><b><input class="ml-5" id="disabled-button" name="submit" type="submit" value="Delete"></b></div>
';
}
else {
    echo'    
    <div class="col-sm-6 mt-4" id="user-id">User id: Unkown</div>
    <div class="col-sm-6 mt-4" id="username">Username: Unkown</div>';
}
}
}
else{
echo'    
<div class="col-sm-6 mt-4" id="user-id">User id: Unkown</div>
<div class="col-sm-6 mt-4" id="username">Username: Unkown</div>';
}
?>