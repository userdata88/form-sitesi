<?php
    require_once ("../v-db/db.php");
    $categories_search2_conn= $conn->query("SELECT * FROM categories");
    $categories_search2_conn->execute([]);
    $categories_search2= $categories_search2_conn->fetchAll(PDO::FETCH_ASSOC);
    if (@$_POST["id"]) {
    $topicid= $_POST["id"];
    if (!empty($topicid)) {
    $title_search_conn= $conn->prepare("SELECT * FROM topics WHERE id LIKE ?");
    $title_search_conn->execute(["%$topicid%"]);
    $title_search= $title_search_conn->fetch(PDO::FETCH_ASSOC);
    $categories=@$title_search["Categori"];
    $categories_search_conn= $conn->prepare("SELECT * FROM categories WHERE id=?");
    $categories_search_conn->execute([$categories]);
    $categories_search= $categories_search_conn->fetch(PDO::FETCH_ASSOC);
    if (@$title_search) {
    echo'     
    <div class="col-12 text-center" id="topic-data">
        <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="topic-id">Topic id: '.$title_search["id"].'</div>
        <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="title">Title: <a href="http://'.$_SERVER["SERVER_NAME"].'/content.php/?id='.$title_search["id"].'" target="_blank">'.$title_search["Title"].'</a></div>
    </div>
        <div class="col-3 mt-4 sett-disabled2">Topic date:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$title_search["Topic_date"].'</p></div>
        <div class="col-3 mt-4 sett-disabled2">Hits:</div>
        <div class="col-7 mt-4 sett-disabled2"><p>'.$title_search["Hits"].'</p></div>
        <div class="col-3 mt-4">Author change:</div>
        <div class="col-7 mt-4"><input class="sett-disabled" type="number"  name="author" style="width:100%;"value="'.$title_search["Author"].'"></div>
        <div class="col-3 mt-4">Title change:</div>
        <div class="col-7 mt-4"><input minlenght="5" class="sett-disabled" type="text"  name="title" style="width:100%;"value="'.$title_search["Title"].'"></div>
        <div class="col-3 mt-4">Categories change:</div>
        <div class="col-7 mt-4"><select name="Categories" id="Topic-categori">
        '; foreach($categories_search2 as $categ){
            if ($categ["id"]==$title_search["Categori"]) {
                echo '<option selected value="'.$categ["id"].'">'.$categ["Name"].'</option>';
            }
            else{
                echo '<option value="'.$categ["id"].'">'.$categ["Name"].'</option>';
            }
              }
              echo'
      </select></div>
        <div class="col-3 mt-4">Content change:</div>
        <div class="col-7 mt-4"><textarea class="sett-disabled" name="about" style="width:100%;">'.$title_search["Content"].'</textarea></div>
        <div id="settings-button" class="col-12 mt-4 text-center settings-button"><b><input id="disabled-button" name="submit" type="submit" value="Save"></b><b><input class="ml-5" id="disabled-button" name="submit" type="submit" value="Delete"></b></div>
';
}
    else {
        echo'    
        <div class="col-sm-6 mt-4" id="topic-id">Topic id: Unkown</div>
        <div class="col-sm-6 mt-4" id="title">Title: Unkown</div>';
    }
}
}
elseif (@$_POST["title"]) {
$title= $_POST["title"];
if (!empty($title)) {
$title_search_conn= $conn->prepare("SELECT * FROM topics WHERE Title LIKE ?");
$title_search_conn->execute(["%$title%"]);
$title_search= $title_search_conn->fetch(PDO::FETCH_ASSOC);
$categories=@$title_search["Categori"];
$categories_search_conn= $conn->prepare("SELECT * FROM categories WHERE id=?");
$categories_search_conn->execute([$categories]);
$categories_search= $categories_search_conn->fetch(PDO::FETCH_ASSOC);
if (@$title_search) {
    
echo'       
<div class="col-12 text-center" id="topic-data">
    <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="topic-id">Topic id: '.$title_search["id"].'</div>
    <div class="col-sm-6 mt-4" style="border-bottom:1px solid lightgray;" id="title">Title: <a href="http://'.$_SERVER["SERVER_NAME"].'/content.php/?id='.$title_search["id"].'" target="_blank">'.$title_search["Title"].'</a></div>
</div>
    <div class="col-3 mt-4 sett-disabled2">Topic date:</div>
    <div class="col-7 mt-4 sett-disabled2"><p>'.$title_search["Topic_date"].'</p></div>
    <div class="col-3 mt-4 sett-disabled2">Hits:</div>
    <div class="col-7 mt-4 sett-disabled2"><p>'.$title_search["Hits"].'</p></div>   
    <div class="col-3 mt-4">Author change:</div>
    <div class="col-7 mt-4"><input class="sett-disabled" type="number"  name="author" style="width:100%;"value="'.$title_search["Author"].'"></div>
    <div class="col-3 mt-4">Title change:</div>
    <div class="col-7 mt-4"><input minlenght="5" class="sett-disabled" type="text"  name="title" style="width:100%;"value="'.$title_search["Title"].'"></div>
    <div class="col-3 mt-4">Categories change:</div>
    <div class="col-7 mt-4"><select name="Categories" id="Topic-categori">
    '; foreach($categories_search2 as $categ){
        if ($categ["id"]==$title_search["Categori"]) {
            echo '<option selected value="'.$categ["id"].'">'.$categ["Name"].'</option>';
        }
        else{
            echo '<option value="'.$categ["id"].'">'.$categ["Name"].'</option>';
        }
          }
          echo'
  </select></div>
    <div class="col-3 mt-4">Content change:</div>
    <div class="col-7 mt-4"><textarea class="sett-disabled" name="about" style="width:100%;">'.$title_search["Content"].'</textarea></div>
    <div id="settings-button" class="col-12 mt-4 text-center settings-button"><b><input id="disabled-button" name="submit" type="submit" value="Save"></b><b><input class="ml-5" id="disabled-button" name="submit" type="submit" value="Delete"></b></div>
';
}
else {
    echo'    
    <div class="col-sm-6 mt-4" id="topic-id">Topic id: Unkown</div>
    <div class="col-sm-6 mt-4" id="title">Title: Unkown</div>';
}
}
}
else{
echo'    
<div class="col-sm-6 mt-4" id="topic-id">Topic id: Unkown</div>
<div class="col-sm-6 mt-4" id="title">Title: Unkown</div>';
}
?>