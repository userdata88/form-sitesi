

<!DOCTYPE html>
<html lang="en">

    <?php
    include_once("head.php");
    session_start();
if ($_SESSION["rank"]==1) {
    require_once("../v-db/db.php"); include_once("../inc/menu.php");

    if(!(@$_GET["page"]==""|| @$_GET["page"]=="Forum" ||@$_GET["page"]=="Footer" || @$_GET["page"]=="Users"||$_GET["page"]=="Topics" ||$_GET["page"]=="Categories" )){
        header("location: http://".$_SERVER["SERVER_NAME"]."/v-admin/");
    }
    $admin_settings_conn= $conn->query("SELECT * FROM forum_settings WHERE verification=0");
    $admin_settings_conn->execute([]);
    $admin_settings=$admin_settings_conn->fetch(PDO::FETCH_ASSOC);
    $Forum_footer_conn=$conn->query("SELECT * FROM forum_footer WHERE verification=0");
    $Forum_footer_conn->execute([]);
    $Forum_footer = $Forum_footer_conn->fetch(PDO::FETCH_ASSOC);
    $settings_ok=null;
    if ($_POST && (@$_GET["page"]=="Forum"||@$_GET["page"]=="")) {
        $forum_name=$_POST["forum-name"];
        $forum_desc=$_POST["forum-desc"];
        $forum_tags=$_POST["forum-tags"];
        $forum_lang=$_POST["forum-lang"];
        $forum_sponsor=@$_POST["forum-sponsor"];

        if (@$_POST["new-topics"]=="on") {
            $forum_new_topics=1;
        }
        else{
            $forum_new_topics=0;
        }
    
        $admin_settings2_conn=$conn->prepare("UPDATE forum_settings set Forum_name=?, Forum_description=?,Forum_tags=?,Forum_lang=?,Forum_new_topics=?,Forum_sponsor=? WHERE verification=0 ");
        $admin_settings2_conn->execute([$forum_name,$forum_desc,$forum_tags,$forum_lang,$forum_new_topics,$forum_sponsor]);
        if ($admin_settings2_conn) {
            $settings_ok="<p class=\"text-success\">Settings saved successfully.</p>";
            ?>
            <script>$(function(){$( "#disabled-button" ).prop("disabled",true);});</script>
            <?php
            header("refresh:2 url=#");
        }
        else{
            $settings_ok="<p class=\"text-danger\">A problem was encountered, please try again.</p>";
            ?>
            <script>$(function(){$( "#disabled-button" ).prop("disabled",true);});</script>
            <?php
            header("refresh:2 url=#");
        }
    }
    if ($_POST && @$_GET["page"]=="Footer") {
        $footer1_content=$_POST["footer1"];
        $footer2_content=$_POST["footer2"];
        $footer3_content=$_POST["footer3"];
        $footer4_content=$_POST["footer4"];
        $footer_copyright=$_POST["footer-copyright"];
        if (empty($footer1_content)) {
            $footer1= 0;
        }
        else{
            $footer1=1;
        }
        if (empty($footer2_content)) {
            $footer2= 0;
        }
        else{
            $footer2=1;
        }
        if (empty($footer3_content)) {
            $footer3= 0;
        }
        else{
            $footer3=1;
        }
        if (empty($footer4_content)) {
            $footer4= 0;
        }
        else{
            $footer4=1;
        }
    
        $footer_settings_conn=$conn->prepare("UPDATE forum_footer set Footer1=?, Footer1_content=?,Footer2=?,Footer2_content=?,Footer3=?,Footer3_content=?,Footer4=?,Footer4_content=?,Footer_copyright=? WHERE verification=0 ");
        $footer_settings_conn->execute([$footer1,$footer1_content,$footer2,$footer2_content,$footer3,$footer3_content,$footer4,$footer4_content,$footer_copyright]);
        if ($footer_settings_conn) {
            $settings_ok="<p class=\"text-success\">Settings saved successfully.</p>";
            ?>
            <script>$(function(){$( "#disabled-button" ).prop("disabled",true);});</script>
            <?php
            header("refresh:2 url=#");
        }
        else{
            $settings_ok="<p class=\"text-danger\">A problem was encountered, please try again.</p>";
            ?>
            <script>$(function(){$( "#disabled-button" ).prop("disabled",true);});</script>
            <?php
            header("refresh:2 url=#");
        }
    }
    if ($_POST && @$_GET["page"]=="Users") {
        if (@$_POST["submit"]=="Save") {
        if (@$_POST["rank"]==true) {
            $rank=1;
        }
        else{
            $rank=0;
        }
        $username=@$_POST["username"];
        $email=@$_POST["e-mail"];
        $about=@$_POST["about"];
        $photo=@$_POST["photo"];
        $signature=@$_POST["signature"];
        $id=@$_POST["id"];
    
        $users_settings_conn=$conn->prepare("UPDATE users set Username=?,E_mail=?,About=?,Photo=?,Signature=?,Rank=? WHERE id=$id ");
        $users_settings_conn->execute([$username,$email,$about,$photo,$signature,$rank]);
        if ($users_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> User settings are saved. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    elseif(@$_POST["submit"]=="Delete"){
        $id=@$_POST["id"];
        $topics_settings_conn2=$conn->prepare("DELETE FROM comments WHERE Author=$id ");
        $topics_settings_conn2->execute([]);
        $topics_settings_conn=$conn->prepare("DELETE FROM topics WHERE Author=$id ");
        $topics_settings_conn->execute([]);
        $users_settings_conn=$conn->prepare("DELETE FROM users WHERE id=$id ");
        $users_settings_conn->execute([]);
        if ($users_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The user has been successfully deleted. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    #######################################################
    }
     if ($_POST && @$_GET["page"]=="Topics") {
        if (@$_POST["submit"]=="Save") {
        if (@$_POST["rank"]==true) {
            $rank=1;
        }
        else{
            $rank=0;
        }
        $title=@$_POST["title"];
        $Categories=@$_POST["Categories"];
        $author=@$_POST["author"];
        $about=@$_POST["about"];
       
    
        $topics_settings_conn=$conn->prepare("UPDATE topics set Title=?,Author=?,Content=?,Categori=?");
        $topics_settings_conn->execute([$title,$author,$about,$Categories]);
        if ($topics_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> User settings are saved. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    elseif(@$_POST["submit"]=="Delete"){
        $id=@$_POST["id"];
        $topics_settings_conn2=$conn->prepare("DELETE FROM comments WHERE Topic=$id ");
        $topics_settings_conn2->execute([]);
        $topics_settings_conn=$conn->prepare("DELETE FROM topics WHERE id=$id ");
        $topics_settings_conn->execute([]);
        if ($topics_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The user has been successfully deleted. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    }
    
if ($_POST && @$_GET["page"]=="Topics") {
        if (@$_POST["submit"]=="Save") {
        if (@$_POST["rank"]==true) {
            $rank=1;
        }
        else{
            $rank=0;
        }
        $title=@$_POST["title"];
        $Categories=@$_POST["Categories"];
        $author=@$_POST["author"];
        $about=@$_POST["about"];
       
    
        $topics_settings_conn=$conn->prepare("UPDATE topics set Title=?,Author=?,Content=?,Categori=?");
        $topics_settings_conn->execute([$title,$author,$about,$Categories]);
        if ($topics_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> User settings are saved. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    elseif(@$_POST["submit"]=="Delete"){
        $id=@$_POST["id"];
        $topics_settings_conn2=$conn->prepare("DELETE FROM comments WHERE Topic=$id ");
        $topics_settings_conn2->execute([]);
        $topics_settings_conn=$conn->prepare("DELETE FROM topics WHERE id=$id ");
        $topics_settings_conn->execute([]);
        if ($topics_settings_conn) {echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The user has been successfully deleted. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
        else{echo'
            <script>$(document).ready(function () {
                $("#users-ok").show().html(\'<div class="alert alert-danger alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> A problem has been encountered. you are being redirected...</div>\');
                $("#user-search").prop("disabled",true);
            });</script>';
              header("refresh:3");
        }
    }
    }

?>
    <body style="background-color:#dedede;">
    <!--Menu-->
        <nav class="container-fluid navbar-dark" style="background-color:#e32d2d">
            <a class="navbar-brand fw-bold" href="#"><?php echo $forum_settings["Forum_name"]?> Admin Panel</a>
            <div class="nav justify-content-end">
                <div class=" login-buttons">
                    <a href="http://<?php echo$_SERVER["SERVER_NAME"]?>/"><div style="width: 100%;"><i title="My topics" class="fa fa-external-link float-end"></i><p class="mt-1">Back to Forum</p></i></div></a>
                </div>
            </div>
        </nav>
    <!--Menu end-->
    
    <!--settings content-->
        <section>
            <div class="container mt-5 mb-5" style="border-radius:10px;">
                <div class="row">
                    <div class="categori-title text-center">Admin settings</div>
                    <div class="col-3 settings-bg">
                        <div class="settings-menu">
                        <a href="?page=Forum"><div class="settings-submenu"><p>Forum</p></div></a>
                        <a href="?page=Footer"><div class="settings-submenu"><p>Footer</p></div></a>
                        <a href="?page=Users"><div class="settings-submenu"><p>Users</p></div></a>
                        <a href="?page=Topics"><div class="settings-submenu"><p>Topics</p></div></a>
                        <a href="?page=Categories"><div class="settings-submenu"><p>Categories</p></div></a>
                        </div>
                    </div>
                    <div class="col-9 settings-bg-2">
                        <?php
                            #Profile page#
                                $forum_page= '
                                <center><strong><div class="settings-subtitle">Forum</strong></center>
                                <form action="" method="post">
                                    <div class="row mt-4">
                                        <div class="col-3 mt-4">Forum name:</div>
                                        <div class="col-7 mt-4"><input type="text" name="forum-name"  style="width:100%;" value="'.$admin_settings["Forum_name"].'"></div>
                                        <div class="col-3 mt-4">Forum Description:</div>
                                        <div class="col-7 mt-4"><input type="text" name="forum-desc"  style="width:100%;" value="'.$admin_settings["Forum_description"].'"></div>
                                        <div class="col-3 mt-4">Forum tags:</div>
                                        <div class="col-5 mt-4"><input type="text" name="forum-tags"  style="width:100%;" value="'.$admin_settings["Forum_tags"].'"></div>
                                        <div class="col-3 mt-4">e.g. Vihkon,Forum</div>
                                        <div class="col-3 mt-4">Forum lang:</div>
                                        <div class="col-5 mt-4"><select name="forum-lang" id="lang" data-placeholder="Choose a Language...">
                                        <option value="af">Afrikaans</option>
                                        <option value="sq">Albanian</option>
                                        <option value="ar">Arabic</option>
                                        <option value="hy">Armenian</option>
                                        <option value="eu">Basque</option>
                                        <option value="bn">Bengali</option>
                                        <option value="bg">Bulgarian</option>
                                        <option value="ca">Catalan</option>
                                        <option value="km">Cambodian</option>
                                        <option value="zh">Chinese (Mandarin)</option>
                                        <option value="hr">Croatian</option>
                                        <option value="cs">Czech</option>
                                        <option value="da">Danish</option>
                                        <option value="nl">Dutch</option>
                                        <option value="en">English</option>
                                        <option value="et">Estonian</option>
                                        <option value="fj">Fiji</option>
                                        <option value="fi">Finnish</option>
                                        <option value="fr">French</option>
                                        <option value="ka">Georgian</option>
                                        <option value="de">German</option>
                                        <option value="el">Greek</option>
                                        <option value="gu">Gujarati</option>
                                        <option value="he">Hebrew</option>
                                        <option value="hi">Hindi</option>
                                        <option value="hu">Hungarian</option>
                                        <option value="is">Icelandic</option>
                                        <option value="id">Indonesian</option>
                                        <option value="ga">Irish</option>
                                        <option value="it">Italian</option>
                                        <option value="ja">Japanese</option>
                                        <option value="jw">Javanese</option>
                                        <option value="ko">Korean</option>
                                        <option value="la">Latin</option>
                                        <option value="lv">Latvian</option>
                                        <option value="lt">Lithuanian</option>
                                        <option value="mk">Macedonian</option>
                                        <option value="ms">Malay</option>
                                        <option value="ml">Malayalam</option>
                                        <option value="mt">Maltese</option>
                                        <option value="mi">Maori</option>
                                        <option value="mr">Marathi</option>
                                        <option value="mn">Mongolian</option>
                                        <option value="ne">Nepali</option>
                                        <option value="no">Norwegian</option>
                                        <option value="fa">Persian</option>
                                        <option value="pl">Polish</option>
                                        <option value="pt">Portuguese</option>
                                        <option value="pa">Punjabi</option>
                                        <option value="qu">Quechua</option>
                                        <option value="ro">Romanian</option>
                                        <option value="ru">Russian</option>
                                        <option value="sm">Samoan</option>
                                        <option value="sr">Serbian</option>
                                        <option value="sk">Slovak</option>
                                        <option value="sl">Slovenian</option>
                                        <option value="es">Spanish</option>
                                        <option value="sw">Swahili</option>
                                        <option value="sv">Swedish </option>
                                        <option value="ta">Tamil</option>
                                        <option value="tt">Tatar</option>
                                        <option value="te">Telugu</option>
                                        <option value="th">Thai</option>
                                        <option value="bo">Tibetan</option>
                                        <option value="to">Tonga</option>
                                        <option value="tr">Turkish</option>
                                        <option value="uk">Ukrainian</option>
                                        <option value="ur">Urdu</option>
                                        <option value="uz">Uzbek</option>
                                        <option value="vi">Vietnamese</option>
                                        <option value="cy">Welsh</option>
                                        <option value="xh">Xhosa</option>
                                      </select></div>
                                      <div class="col-4 mt-4">this is for search engines only</div>
                                      <div class="col-3 mt-4">Show new topics:</div>
                                      <div class="col-7 mt-4"><input id="settings-new-topic" type="checkbox" name="new-topics" size="50"></div>
                                      <div class="col-3 mt-4">Forum sponsor:</div>
                                      <div class="col-7 mt-4"><textarea name="forum-sponsor" style="width:100%;">'.$admin_settings["Forum_sponsor"].'</textarea></div>
                                        <div id="settings-button" class="col-12 mt-4 text-center settings-button">'.$settings_ok.'<b><input id="disabled-button" type="submit" value="Save"></b></div>
                                    </div>
                                </form>';
                            #Profil page end#

                            #Pagination#
                                if (!(empty($_GET["page"]))) {

                                    #Security page#
                                        if ($_GET["page"]=="Footer") {
                                            echo '<center><strong><div class="settings-subtitle">Forum</strong></center>
                                            <form action="" method="post">
                                                <div class="row mt-4">
                                                    <div class="col-3 mt-4">Footer 1:</div>
                                                    <div class="col-7 mt-4"><textarea name="footer1" style="width:100%;">'.$Forum_footer["Footer1_content"].'</textarea></div>
                                                    <div class="col-3 mt-4">Footer 2:</div>
                                                    <div class="col-7 mt-4"><textarea name="footer2" style="width:100%;">'.$Forum_footer["Footer2_content"].'</textarea></div>
                                                    <div class="col-3 mt-4">Footer 3:</div>
                                                    <div class="col-7 mt-4"><textarea name="footer3" style="width:100%;">'.$Forum_footer["Footer3_content"].'</textarea></div>
                                                    <div class="col-3 mt-4">Footer 4:</div>
                                                    <div class="col-7 mt-4"><textarea name="footer4" style="width:100%;">'.$Forum_footer["Footer4_content"].'</textarea></div>
                                                    <div class="col-3 mt-4">&copy; Footer Copyright:</div>
                                                    <div class="col-7 mt-4"><input type="text" name="footer-copyright" style="width:100%;" value="'.$Forum_footer["Footer_copyright"].'"></div>
                                                    <div id="settings-button" class="col-12 mt-4 text-center settings-button">'.$settings_ok.'<b><input id="disabled-button" type="submit" value="Save"></b></div>
                                                </div>
                                            </form>
                                            ';
                                    #Security page end#

                                    #Privacy page#
                                        }elseif ($_GET["page"]=="Users") {
                                            echo '<center><strong><div class="settings-subtitle">Users</strong></center>
                                            
                                                <div class="row">
                                                    <div class="col-3 mt-4">User Search:</div>
                                                    <div class="col-5 mt-4"><input id="user-search" type="text" name="user-search" style="width:100%;"></div>
                                                    <div class="col-1 mt-4"><button id="button-id" class="admin-button-selected" style="border-radius:5px;font-size:20px;padding-left:15px;padding-right:15px;background-color:#e32d2d;color:white;border:none;">id</button></div>
                                                    <div class="col-1 mt-4"><button id="button-username" style="border-radius:5px;font-size:20px;padding-left:3px;padding-right:3px;background-color:#e32d2d;color:white;border:none;">Username</button></div>
                                                </div>
                                            <form action="" method="post">
                                                <div class="row mt-4" id="user-data">
                                                    <div class="col-12">
                                                    <div class="col-sm-6 mt-4" id="user-id">User id: Unkown</div>
                                                    <div class="col-sm-6 mt-4" id="username">Username: Unkown</div>
                                                    </div>
                                                </div>
                                                <input id="sett-user-id" type="hidden" name="id">
                                            </form>
                                            
                                            <div id="users-ok" style="display:none;position:fixed;right:10px;top:30px"></div>
                                            <script>function control2() {
                                                if ($("#button-id").hasClass("admin-button-selected")) {
                                                    var id=$("#user-search").val();
                                                    $.ajax({url:"user.php",type:"post",data:"id="+id,success:function(data){
                                                        $("#user-data").html(data);
                                                        var users=$("#user-id").html();
                                                        $("#sett-user-id").val(users.substr(9,));
                                                    }});
                                                }
                                                else if ($("#button-username").hasClass("admin-button-selected")) {
                                                    var id=$("#user-search").val();
                                                    $.ajax({url:"user.php",type:"post",data:"Username="+id,success:function(data){
                                                        $("#user-data").html(data);
                                                        var users=$("#user-id").html();
                                                        $("#sett-user-id").val(users.substr(9,));
                                                    }});
                                                }
                                            }
                                            $(function () {
                                                $("#button-id").click(function () {
                                                    $("#button-id").addClass("admin-button-selected");
                                                    $("#button-username").removeClass("admin-button-selected");
                                                });
                                                $("#button-username").click(function () {
                                                    $("#button-id").removeClass("admin-button-selected");
                                                    $("#button-username").addClass("admin-button-selected");
                                                });
                                               
                                                    $("#user-search").keyup(function(){
                                                    control2();                    
                                                    });
                                                    $("#button-username,#button-id").click(function(){
                                                    control2();
                                                    });
                                               
                                
                                                
                                            });
                                        </script>
                                            ';}
                                    #Privacy page end#
                                    elseif ($_GET["page"]=="Topics") {
                                        echo '<center><strong><div class="settings-subtitle">Topics</strong></center>
                                        
                                            <div class="row">
                                                <div class="col-3 mt-4">Topic Search:</div>
                                                <div class="col-5 mt-4"><input id="topic-search" type="text" name="topic-search" style="width:100%;"></div>
                                                <div class="col-1 mt-4"><button id="button-id" class="admin-button-selected" style="border-radius:5px;font-size:20px;padding-left:15px;padding-right:15px;background-color:#e32d2d;color:white;border:none;">id</button></div>
                                                <div class="col-1 mt-4"><button id="button-title" style="border-radius:5px;font-size:20px;padding-left:3px;padding-right:3px;background-color:#e32d2d;color:white;border:none;">Title</button></div>
                                            </div>
                                        <form action="" method="post">
                                            <div class="row mt-4" id="topic-data">
                                                <div class="col-12">
                                                <div class="col-sm-6 mt-4" id="topic-id">Topics id: Unkown</div>
                                                <div class="col-sm-6 mt-4" id="title">Title: Unkown</div>
                                                </div>
                                            </div>
                                            <input id="sett-topic-id" type="hidden" name="id">
                                        </form>
                                        
                                        <div id="topic-ok" style="display:none;position:fixed;right:10px;top:30px"></div>
                                        <script>function control() {
                                            if ($("#button-id").hasClass("admin-button-selected")) {
                                                var id=$("#topic-search").val();
                                                $.ajax({url:"topic.php",type:"post",data:"id="+id,success:function(data){
                                                    $("#topic-data").html(data);
                                                    var topics=$("#topic-id").html();
                                                    $("#sett-topic-id").val(topics.substr(9,));
                                                }});
                                            }
                                            else if ($("#button-title").hasClass("admin-button-selected")) {
                                                var id=$("#topic-search").val();
                                                $.ajax({url:"topic.php",type:"post",data:"title="+id,success:function(data){
                                                    $("#topic-data").html(data);
                                                    var topics=$("#topic-id").html();
                                                    $("#sett-topic-id").val(topics.substr(9,));
                                                }});
                                            }
                                        }
                                        $(function () {
                                            $("#button-id").click(function () {
                                                $("#button-id").addClass("admin-button-selected");
                                                $("#button-title").removeClass("admin-button-selected");
                                            });
                                            $("#button-title").click(function () {
                                                $("#button-id").removeClass("admin-button-selected");
                                                $("#button-title").addClass("admin-button-selected");
                                            });
                                           
                                                $("#topic-search").keyup(function(){
                                                control();                    
                                                });
                                                $("#button-title,#button-id").click(function(){
                                                control();
                                                });
                                           
                            
                                            
                                        });
                                    </script>';}
                                    elseif ($_GET["page"]=="Categories") {
                                            if(@$_POST["categories-settings"]=="Add"){
                                            $catoregister=$conn->prepare("insert into categories set
                                            Name=?");
                                            
                                            $register_categories=$_POST["registercategories"];
                                            if(!$register_categories){
                                                echo "Boş bırakılamaz";
                                            }else{
                                                $registerc=$catoregister->execute(array($register_categories));
                                                if($registerc){?>
                                                    <script>$(function () {
                                                        $(":submit").prop("disabled",true);
                                                        $("#categories-ok").show().html('<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The category has been successfully added. you are being redirected...</div>');
                                                      });</script>
                                                      <?php
                                                      header("refresh:3");
                                                }
                                                

                                            }
                                        }
                                        if(@$_POST["categories-settings"]=="Update"){
                                            $categori_update_id=@$_POST["select-id-update"];
                                            if (@$_POST["categories-name"]=="") {
                                                $categories_control_conn = $conn->query("SELECT * FROM categories WHERE id=$categori_update_id");
                                                $categories_control_conn->execute([]);
                                                $categories_control=$categories_control_conn->fetch(PDO::FETCH_ASSOC);
                                                $categori_update_name=$categories_control["Name"];
                                            }
                                            else {
                                                $categori_update_name=@$_POST["categories-name"];
                                            }
                                            if (@$_POST["show-categori"]==1) {
                                                $show_categori=0;
                                            }
                                            else{
                                                
                                            $show_categori=1;
                                            }
                                            echo $categori_update_id;
                                            $categories_settings = $conn->prepare("UPDATE categories SET Name=:name,Hide=:hide WHERE id=:id");
                                            $categories_settings->execute([":name" => $categori_update_name,":hide"=>$show_categori, ":id" => $categori_update_id]);
                                            if ($categories_settings) {?>
                                                <script>$(function () {
                                                    $(":submit").prop("disabled",true);
                                                    $("#categories-ok").show().html('<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The category has been successfully changed. you are being redirected...</div>');
                                                  });</script>
                                                  <?php
                                                  header("refresh:3");
                                            }
                                        }
                                        if(@$_POST["categories-settings"]=="Delete"){
                                            $categori_update_id=@$_POST["select-id-delete"];
                                            $categories_settings = $conn->prepare("DELETE FROM categories WHERE id=:id");
                                            $categories_settings->execute([":id" => $categori_update_id]);
                                            $categories2_settings = $conn->prepare("DELETE FROM topics WHERE Categori=:id");
                                            $categories2_settings->execute([":id" => $categori_update_id]);
                                            $categories3_settings = $conn->prepare("DELETE FROM comments WHERE Categori=:id");
                                            $categories3_settings->execute([":id" => $categori_update_id]);
                                            if ($categories_settings) {?>
                                                <script>$(function () {
                                                    $(":submit").prop("disabled",true);
                                                    $("#categories-ok").show().html('<div class="alert alert-success alert-dismissible"><a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success</strong> The category has been successfully changed. you are being redirected...</div>');
                                                  });</script>
                                                  <?php
                                                  header("refresh:3");
                                            }
                                        }
                                           
                                            $categories = $conn->query("SELECT * FROM categories");
                                            $categories->execute([]);
                                            $categories_output = $categories->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            
                                           
                                        
                                       
                                        echo '<center><strong><div class="settings-subtitle">Categories</strong></center>
                                        
                                           
                                        <form action="" method="post">
                                            <div class="row mt-4">
                                                
                                                <div class="col-3 mt-4">Categories add:</div>
                                                <div class="col-7 mt-4"><input id="topic-search" type="text" name="registercategories" style="width:100%;"></div>
                                               <div class="col-3 mt-4">Categories update:</div>
                                               <div class="col-3 mt-4"><input type="text" name="categories-name"></div>
                                               <div class="col-2 mt-4"><select id="categories"  name="select-id-update">';foreach($categories_output as $categori){echo'<option value="'.$categori["id"].'">'.$categori["Name"].'</option>'; }echo'</select></div>
                                               <div class="col-4 mt-4">Show:<input type="checkbox" name="show-categori" value="1"></div>
                                               <div class="col-3 mt-4">Categories Delete:</div>
                                               <div class="col-6 mt-4"><select id="categories" name="select-id-delete">';foreach($categories_output as $categori){echo'<option value="'.$categori["id"].'">'.$categori["Name"].'</option>'; }echo'</select></div>
                                               <div id="settings-button" class="col-12 mt-4 text-center settings-button"><b><input name="categories-settings" type="submit" value="Add"></b><b><input class="ml-5" name="categories-settings" type="submit" value="Update"></b><b><input class="ml-5" name="categories-settings" type="submit" value="Delete"></b></div>
                                            </div>
                                            </form>
                                            
                                        
                                        <div id="categories-ok" style="display:none;position:fixed;right:10px;top:30px"></div>
                                        ';}
                                    
                                    else{echo $forum_page;}
                                }else{echo $forum_page;}
                            #Pagination end#
                            
                        ?>
                    </div>
                </div>
            </div>
        </section>
        
        <?php include_once("footer.php");?>
        <script>
        $("select#lang").val("<?php echo $admin_settings["Forum_lang"];?>");
                if (<?php echo $admin_settings["Forum_new_topics"];?> == 1 ) {
                $("#settings-new-topic").prop("checked",true);
                }
        </script>
        
        <style>
            .admin-button-selected{
                font-size:18px !important;
                color:lightgray !important;
                border:2px solid rgb(36, 36, 36) !important;
}
        </style>
    </body>
</html>
<?php
}else{
    header("Location: http://".$_SERVER["SERVER_NAME"]."");
}