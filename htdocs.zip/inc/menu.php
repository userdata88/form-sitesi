<?php

$domain_head="http://".$_SERVER["SERVER_NAME"];
if($_SERVER["REQUEST_URI"]=="/inc/menu.php"){header("Location: $domain_head");}
function menu_profile($id){
    echo'
    <a href="http://'.$_SERVER["SERVER_NAME"].'/mytopics.php"><div style="width: 33%;"><i title="My topics" class="fa fa-list-alt"></i><p class="mt-1">My Topics</p></i></div></a>
    <a href="http://'.$_SERVER["SERVER_NAME"].'/profile.php/?id='.$id.'"><div style="width: 33%;"><i title="My Profil" class="fa fa-user"></i><p class="mt-1">My Profile</p></i></div></a>
    <a href="http://'.$_SERVER["SERVER_NAME"].'/exit.php"><div style="width: 33%;"><i title="Exit" class="fa fa-close"></i><p class="mt-1">Exit</p></i></div></a>';
}

function menu_login(){
    echo'
    <a href="http://'.$_SERVER["SERVER_NAME"].'/login.php"><div style="width: 40%;"><i title="Login" class="fa fa-sign-in"><p class="mt-1">Log in</p></i></div></a>
    <a href="http://'.$_SERVER["SERVER_NAME"].'/signup.php"><div style="width: 40%;"><i title="Sign up" class="fa fa-user-plus"><p class="mt-1">Sign up</p></i></div></a>';
}

?>

