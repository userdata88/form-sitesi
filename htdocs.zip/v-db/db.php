<?php
$domain_head="http://".$_SERVER["SERVER_NAME"];
if($_SERVER["REQUEST_URI"]=="/v-db/db.php"){header("Location: $domain_head");}
    $db_server = "localhost";
    $db_name = "vdb";
    $db_username = "root";
    $db_pass = "";
    try {
        $conn = new PDO("mysql:host=$db_server;dbname=$db_name;charset=utf8", $db_username, $db_pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
    catch(PDOException $e)
        {
        echo "Contection Error: " . $e->getMessage();
        }

        
$topic = $conn->query("SELECT * FROM topics order by id DESC limit 20");
$topic2 = $conn->query("SELECT * FROM topics");
$categories = $conn->query("SELECT * FROM categories order by rand() limit 4");
$categories2 = $conn->query("SELECT * FROM categories");
$user_conn=$conn->query("SELECT * FROM users");
$Forum_settings_conn=$conn->query("SELECT * FROM forum_settings");

$topic->execute([]);
$topic2->execute([]);
$categories->execute([]);
$categories2->execute([]);
$user_conn->execute([]);
$Forum_settings_conn->execute([]);

$topic_output = $topic->fetchAll(PDO::FETCH_ASSOC);
$topic_output2 = array_reverse($topic2->fetchAll(PDO::FETCH_ASSOC));
$categories_output = array_reverse($categories->fetchAll(PDO::FETCH_ASSOC));
$categories_output2 = array_reverse($categories2->fetchAll(PDO::FETCH_ASSOC));
$user_fetch = $user_conn->fetch(PDO::FETCH_ASSOC);
$forum_settings = $Forum_settings_conn->fetch(PDO::FETCH_ASSOC);

function settings($conn,$user_name,$e_mail,$password,$settings_id){
        
    $settings_profile = $conn->prepare("UPDATE users SET Username=:username, E_mail=:e_mail, Password=:password WHERE id=:id");
    $settings_profile->execute([":username" => $user_name, ":e_mail" => $e_mail, ":password"=>$password, ":id" => $settings_id]);
    
}
?>